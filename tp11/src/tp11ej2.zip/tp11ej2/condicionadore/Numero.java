package tp11ej2.condicionadore;

import tp11ej2.Figura;

public class Numero extends Condicion{
    private int numero;

    public Numero(int numero) {
        this.numero = numero;
    }

    @Override
    public
}
