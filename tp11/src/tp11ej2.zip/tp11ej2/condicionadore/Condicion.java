package tp11ej2.condicionadore;

import tp11ej2.Figura;

public abstract class Condicion {
    public abstract boolean cumple(Figura f);
}
