package tp11ej2;

import tp11ej2.condicionadore.Condicion;

public abstract class Elemento {


     public abstract double getprecio();

     public abstract Elemento copia(Condicion condicion);



}
