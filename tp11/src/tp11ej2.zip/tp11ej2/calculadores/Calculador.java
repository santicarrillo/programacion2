package tp11ej2.calculadores;

import tp11ej2.FiguritaLimite;

public abstract class Calculador {
    public abstract double calcula (FiguritaLimite fl);


}
