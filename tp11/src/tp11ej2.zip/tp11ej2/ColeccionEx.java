package tp11ej2;

import tp11ej2.condicionadore.Condicion;

public class ColeccionEx extends Coleccion{

    public ColeccionEx(int descuento) {
        super(descuento);
    }

    @Override
    public Elemento copia(Condicion condicion) {
        return null;
    }
}
