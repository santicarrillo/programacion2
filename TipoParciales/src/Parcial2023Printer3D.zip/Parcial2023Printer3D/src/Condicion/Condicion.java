package Parcial2023Printer3D.src.Condicion;

import Parcial2023Printer3D.src.Elemento;
import Parcial2023Printer3D.src.Pieza;

public abstract class Condicion {
    public abstract boolean cumple(Elemento e);


}
