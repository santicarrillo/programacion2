public class PiezaExclusiva {
}
