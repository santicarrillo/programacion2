import java.util.ArrayList;

public class PiezaCompuesta extends Elemento{
    private ArrayList<Elemento> elementos;
    public PiezaCompuesta(String nombre, String descripcion, double precioPla, double costoSegundoImpresion,double extra){
        super(nombre,descripcion,precioPla,costoSegundoImpresion,extra);
        this.elementos=new ArrayList<>();
    }
    public ArrayList<Elemento> getElementos() {
        return new ArrayList<>(elementos);
    }
    public void addElementos(Elemento e) {
        elementos.add(e);
    }
    @Override
    public double getTiempoEstimado(){
        double suma=0;
        for(Elemento e:elementos){
            suma+=e.getTiempoEstimado()+e.getExtra();
        }
        return suma;
    }



}
