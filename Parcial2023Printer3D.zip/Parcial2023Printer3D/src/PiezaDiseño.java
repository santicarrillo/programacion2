public class PiezaDiseño {
}
